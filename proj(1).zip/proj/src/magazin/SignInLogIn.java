package magazin;

import javax.swing.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

public class SignInLogIn extends JDialog {
    private JPanel contentPane;
    private JTextField un;
    private JPasswordField pass;
    private JButton submitButton;
    private JButton logInButton;

    public SignInLogIn() {
        setContentPane(contentPane);
        setModal(true);
//        getRootPane().setDefaultButton(buttonOK);

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    onSubmit();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
//
//        buttonCancel.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                onCancel();
//            }
//        });

        logInButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onLogIn();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onSubmit() throws IOException {
        String username = un.getText();
        String password = pass.getText();

        System.out.println("\n" + username + " : " + password);
        try {
            FileWriter writer = new FileWriter("src/magazin/users.txt", true);
            writer.append("\n" + username + " : " + password);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void onLogIn() {
        if (this.un.getText().equals("aleks") && this.pass.getText().equals("admin")) {
            pokupka p = new pokupka();
            p.setSize(600, 600);
            p.setLocationRelativeTo(null);
            p.setVisible(true);
            System.exit(0);
        }
        else {
            System.out.println("Wrong credentials!");
        }
    }

    public void hideSubmit() {
        this.submitButton.setVisible(false);
    }

    public void hideLogIn() {
        this.logInButton.setVisible(false);
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        SignInLogIn dialog = new SignInLogIn();
        dialog.setSize(600, 600);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
        System.exit(0);
    }
}
