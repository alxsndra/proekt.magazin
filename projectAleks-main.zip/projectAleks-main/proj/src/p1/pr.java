package p1;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class pr extends JDialog {
    private JPanel contentPane;
    private JButton submitButton;
    private JTextField name;
    private JTextField age;
    private JButton print;
    private JTextPane textPane;
    private ArrayList<Person> people;

    public pr() {
        this.people = new ArrayList<>();
        setContentPane(contentPane);
        setModal(true);
//        getRootPane().setDefaultButton(buttonOK);

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onSubmit();
            }
        });

        print.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onPrint();
            }
        });

        // call onCancel() when cross is clicked
//        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
//        addWindowListener(new WindowAdapter() {
//            public void windowClosing(WindowEvent e) {
//                close();
//            }
//        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                close();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onSubmit() {
        String name = this.name.getText();
        int age = Integer.parseInt(this.age.getText());
        Person p1 = new Person(name, age);
        this.people.add(p1);
        this.name.setText(null);
        this.age.setText(null);
    }

    private void onPrint() {
        String text = "";
        for (int i = 0; i < this.people.size(); i++) {
            text += this.people.get(i).toString() + "\n";
        }
        this.textPane.setText(text);
    }

    private void close() {
        dispose();
    }

    public static void main(String[] args) {
        pr dialog = new pr();
        dialog.setSize(300, 400);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
        System.exit(0);
    }
}
