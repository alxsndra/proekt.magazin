package magazin;

import javax.swing.*;
import java.awt.event.*;


public class magazin extends JDialog {
    private JPanel contentPane;
    private JButton logInButton;
    private JButton signUpButton;

    public magazin() {
        setContentPane(contentPane);
        setModal(true);
//        getRootPane().setDefaultButton(buttonOK);

        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onSignUp();
            }
        });

        logInButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onLogIn();
            }
        });
//
//        buttonCancel.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                onCancel();
//            }
//        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
//                onCancel();
            }
        });

        // call onCancel() on ESCAPE
//        contentPane.registerKeyboardAction(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                onCancel();
//            }
//        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onSignUp() {
        SignInLogIn signWindow = new SignInLogIn();
        signWindow.hideLogIn();
        signWindow.setSize(600, 600);
        signWindow.setLocationRelativeTo(null);
        signWindow.setVisible(true);
        System.exit(0);
    }

    private void onLogIn() {
        SignInLogIn signWindow = new SignInLogIn();
        signWindow.hideSubmit();
        signWindow.setSize(600, 600);
        signWindow.setLocationRelativeTo(null);
        signWindow.setVisible(true);
        System.exit(0);
    }

    public static void main(String[] args) {
        magazin dialog = new magazin();
//        dialog.pack();
        dialog.setSize(600, 600);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
        System.exit(0);
    }
}
