package magazin;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        FileWriter writer = new FileWriter(new File("src/magazin/users.txt"));

        writer.write("1");

        writer.close();
    }
}
